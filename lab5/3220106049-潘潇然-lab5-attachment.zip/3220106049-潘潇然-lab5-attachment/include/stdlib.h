#ifndef __STDLIB_H__
#define __STDLIB_H__

int rand(void);
void srand(unsigned);

#endif

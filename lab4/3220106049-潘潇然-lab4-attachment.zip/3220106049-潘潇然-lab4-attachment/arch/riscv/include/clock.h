#ifndef __CLOCK_H__
#define __CLOCK_H__

#include "stdint.h"

void clock_set_next_event();

#endif
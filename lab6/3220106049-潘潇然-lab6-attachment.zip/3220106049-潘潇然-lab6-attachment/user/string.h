#ifndef __STRING_H__
#define __STRING_H__

int strlen(const char *str);

#endif